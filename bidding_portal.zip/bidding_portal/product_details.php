<link rel="stylesheet" type="text/css" href="assets/templates/techmaster-html5/css/layout.css?vcart=7.2.0">
<link rel="stylesheet" type="text/css" href="assets/templates/techmaster-html5/css/default.css?vcart=7.2.0">
<link rel="stylesheet" href="bootstrap.css">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>Welcome to Sample Store  - Sample Slogan</title>
<script src="assets/countdown.js"></script>
<link rel="canonical" href="http://techmaster-preview-com.3dcartstores.com">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
<script type="text/javascript" src="assets/templates/common-html5/js/modernizr.min.js?vcart=7.2.0"></script>
<script type="text/javascript" src="assets/templates/common-html5/js/utilities.js?vcart=7.2.0"></script>
<script type="text/javascript" src="assets/templates/common-html5/js/jquery.min.js"></script>
<script type="text/javascript" src="assets/templates/common-html5/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="assets/templates/common-html5/quicksearch/quicksearch.css?vcart=7.2.0" type="text/css" media="screen">
<link rel="stylesheet" href="assets/templates/common-html5/css/layout.css?vcart=7.2.0" type="text/css" media="all">
<link rel="stylesheet" href="assets/templates/common-html5/css/responsive.css?vcart=7.2.0" type="text/css" media="screen">
<link rel="stylesheet" href="assets/templates/techmaster-html5/css/default.css?vcart=7.2.0" type="text/css" media="screen">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Roboto+Slab:400,300,700" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="assets/templates/common-html5/css/fontello.css?vcart=7.2.0">
<!--[if IE 7]>
<link rel="stylesheet" href="assets/templates/common-html5/css/fontello-ie7.css?vcart=7.2.0" />
<![endif]-->
<!--START: FRAME_RSSFEEDS -->
<link rel="alternate" type="application/rss+xml" title="Featured Items (RSS 2.0)" href="http://techmaster-preview-com.3dcartstores.com/rss.asp?type=home">
<link rel="alternate" type="application/rss+xml" title="Products On Sale (RSS 2.0)" href="http://techmaster-preview-com.3dcartstores.com/rss.asp?type=onsale">
<link rel="alternate" type="application/rss+xml" title="New Releases (RSS 2.0)" href="http://techmaster-preview-com.3dcartstores.com/rss.asp?type=newreleases">
<link rel="alternate" type="application/rss+xml" title="Best Sellers (RSS 2.0)" href="http://techmaster-preview-com.3dcartstores.com/rss.asp?type=bestsellers">
<link rel="alternate" type="application/rss+xml" title="Latest Blog Posts (RSS 2.0)" href="http://techmaster-preview-com.3dcartstores.com/rss.asp?type=blog">
<!--END: FRAME_RSSFEEDS -->
<link rel="stylesheet" href="bootstrap.css">
<script type="text/javascript">
    if (typeof jQuery == 'undefined') {
        document.write("<script type=\"text/javascript\" src=\"/assets/templates/common-html5/js/jquery.min.js?vcart=7.2.0\"></" + "script>");
    }
</script>
<script>
function abc(time1){
	var intervalID = window.setInterval(myCallback, 1000);
	function myCallback(){
		var seconds = new Date().getTime();
		var d = new Date(time1);
		console.log(d);
		document.getElementById('count_down').innerHTML = "Will Start in : "+countdown(time1, seconds, countdown.DEFAULTS).toString();
	}
}
</script>
<link media="screen" rel="stylesheet" href="/assets/templates/common-html5/js/quick_view.css?vcart=7.2.0">
<style>
    li{
        list-style-type: none;
    }
    #FRAME_SEARCH{
        padding: 40px 0px;        
    }
    #homeCarousel{
    }
    #grad {
    min-height: 400px;
    width: 100%;
    background: linear-gradient(141deg, #0fb8ad 0%, #1fc8db 51%, #2cb5e8 75%);
    color: white;
    opacity: 0.95;
    }
</style>
<style type="text/css">
	.row{
		margin: 10vh 0;
	}
</style>
<header>
    <div class="wrapper" style="padding: 30px;">
        <div class="col-md-6 h1">Bid-o-Bid</div>
        <div class="col-md-6 pull-right" style="text-align: right;"><br>
            <div class="dropdown pull-right">
          <button class="btn btn-danger dropdown-toggle" type="button" data-toggle="dropdown">
            Welcome, pinku          <span class="caret"></span></button>
          <ul class="dropdown-menu">
            <li><a href="#">HTML</a></li>
            <li><a href="#">CSS</a></li>
            <li><a href="#">JavaScript</a></li>
			<li><a href="insert_product_details.php">Insert product Details</a></li>
          </ul>
        </div>
        </div>
    </div>
</header>
<div class="container">
<div class="row">
<?php

	function manipulate($start_time, $end_time){
		$current_time = date("Y-m-d H:i:s");
		if ($current_time>=$start_time && $current_time<=$end_time) {
			echo "<button class='btn btn-lg btn-success'>";
			echo "Countdown Start";
			echo "</button>";
		} else if($current_time>$end_time){
			echo "<button class='btn btn-lg btn-danger' disabled>";
			echo "Bidding Close";
			echo "</button>";
		} else if($current_time<$start_time){
			//echo ($current_time)*1000;
			//echo $start_time;
			date_default_timezone_set('Asia/Kolkata');
			$et = strtotime($start_time)*1000;
			echo "<button class='btn btn-info btn-lg' id='count_down' disabled>";
			echo "Will Start in :";
			echo "<script>abc(".$et.");</script>";
			echo "</button>";
		}
	}
	require 'config.php';
	$id=$_GET['id'];

	$sql="SELECT * from product_table where product_id='$id'";
	$sql1="SELECT * from image_table where product_id='$id'";
	
	$query = mysqli_query($con,$sql);
	$query1= mysqli_query($con,$sql1);
	
	$row= mysqli_fetch_array($query);
	$row1= mysqli_fetch_array($query1);

	if ($row && $row1) {
		$product_name = $row['product_name'];
		$base_price = $row['base_price'];
		$shipping_price= $row['shipping_price'];
		$bid_reset_time = $row['bid_reset_time'];
		$bid_start_time = $row['bid_start_time'];
		$bid_end_time = $row['bid_end_time'];
		$credits_used_per_bid = $row['credits_used_per_bid'];
		$product_description = $row['product_description'];
		$loc = $row1['image_location'];
		echo '<div class="col-md-6">';
		echo '<img src="'.$loc.'" alt="'.$product_name.'" id="qv_2" class="img-responsive" />';
		echo "</div>";	
		echo '<div class="col-md-6">';	
		echo "<h2>".strtoupper($product_name)."</h2>";
		echo "<p>$product_description</p>";
		echo manipulate($bid_start_time, $bid_end_time)."<br><br>";
		echo '<table class="table table-sm panel panel-default">
  <tbody>
    <tr>
      <td>Base Price</td>
      <td>Rs '.$base_price.'</td>
    </tr>
    <tr>
      <td>Shipping Price</td>
      <td>Rs '.$shipping_price.'</td>
    </tr>
    <tr>
      <td>Bidding Reset Time</td>
      <td>'.$bid_reset_time.'</td>
    </tr>
    <tr>
      <td>Credits Used per bidding</td>
      <td>'.$credits_used_per_bid.'</td>
    </tr>
  </tbody>
</table>';
	} else {
	
		header("location: index.php?message=Username or Password is incorrect");

	}
		mysqli_close($con); // Closing Connection
	?>
</div>
</div>
</div>
<footer>
    <div class="wrapper"> 
      <div class="ftr-col col1">
      <div id="FRAME_LINKS"><!--START: FRAME_LINKS-->
      <div id="modLinks">
          <h3>Links</h3>
          <ul class="frame-links">
            <!--START: LINKS-->
            <li><a href="blog.asp" target="_self" class="menu-bottom">Blog</a></li>
            
            <li><a href="Terms-and-Conditions_ep_2-1.html" target="_self" class="menu-bottom">Terms and Conditions</a></li>
            
            <li><a href="affiliateInfo.asp" target="_self" class="menu-bottom">Become an Affiliate</a></li>
            
            <li><a href="product_index.asp" target="_self" class="menu-bottom">Product Index</a></li>
            
            <li><a href="category_index.asp" target="_self" class="menu-bottom">Category Index</a></li>
            <!--END: LINKS-->
          </ul>
      </div>
      <!--END: FRAME_LINKS--></div> 
      </div>
      <div class="ftr-col col3">
      <!--START: FRAME_MAILLIST-->
      <div id="mailistBox">
        <form method="post" name="mailing" action="https://techmaster-preview-com.3dcartstores.com/mailing_list.asp?action=add" onsubmit="return mailing_list();">
          <label>Mailing List</label>
          <div class="mailist-box">
            <input type="text" name="email" value="" placeholder="Email Address">
            <input type="submit" name="www" value="GO">
            <div class="clear"></div>
          </div>
          <input type="radio" name="subscribe" value="1" checked="checked">
          <span class="menu-text">Subscribe</span>
          <input type="radio" name="subscribe" value="0">
          <span class="menu-text">Unsubscribe</span>
          <div class="clear"></div>
        </form>
        <div class="clear"></div>
      </div>
      <!--END: FRAME_MAILLIST-->
      <div class="clear"></div> 
      </div>
      <div class="clear"></div>
      <div id="globalFooter" class="footer"></div>
      <div class="clear"></div>     
    </div>
  </footer>
  <div id="copyright" class="footer">
    <div class="wrapper">Copyright  <script type="text/javascript" language="javascript">var date = new Date(); document.write(date.getFullYear())</script>2016 Sample Store. All Rights Reserved. eCommerce Software by <a href="http://www.3dcart.com">3dcart</a>.</div>
  </div>