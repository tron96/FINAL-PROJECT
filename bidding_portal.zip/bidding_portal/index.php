<?php
session_start();

if(isset($_SESSION['username'])){
header("location: home.php");
}
?>

<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js">
<!--<![endif]-->
<head>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>Welcome to Sample Store  - Sample Slogan</title>
<link rel="canonical" href="http://techmaster-preview-com.3dcartstores.com" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0" />

<script type="text/javascript" src="assets/templates/common-html5/js/modernizr.min.js?vcart=7.2.0"></script>
<script type="text/javascript" src="assets/templates/common-html5/js/utilities.js?vcart=7.2.0"></script>
<link rel="stylesheet" href="assets/templates/common-html5/quicksearch/quicksearch.css?vcart=7.2.0" type="text/css" media="screen" />
<link rel="stylesheet" href="assets/templates/common-html5/css/layout.css?vcart=7.2.0" type="text/css" media="all" />
<link rel="stylesheet" href="assets/templates/common-html5/css/responsive.css?vcart=7.2.0" type="text/css" media="screen" />
<link rel="stylesheet" href="assets/templates/techmaster-html5/css/default.css?vcart=7.2.0" type="text/css" media="screen" />
<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700' rel='stylesheet' type='text/css' />
<link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,300,700' rel='stylesheet' type='text/css' />
<link rel="stylesheet" href="assets/templates/common-html5/css/fontello.css?vcart=7.2.0" />
<!--[if IE 7]>
<link rel="stylesheet" href="assets/templates/common-html5/css/fontello-ie7.css?vcart=7.2.0" />
<![endif]-->
<!--START: FRAME_RSSFEEDS -->
<link rel="alternate" type="application/rss+xml" title="Featured Items (RSS 2.0)" href="http://techmaster-preview-com.3dcartstores.com/rss.asp?type=home" />
<link rel="alternate" type="application/rss+xml" title="Products On Sale (RSS 2.0)" href="http://techmaster-preview-com.3dcartstores.com/rss.asp?type=onsale" />
<link rel="alternate" type="application/rss+xml" title="New Releases (RSS 2.0)" href="http://techmaster-preview-com.3dcartstores.com/rss.asp?type=newreleases" />
<link rel="alternate" type="application/rss+xml" title="Best Sellers (RSS 2.0)" href="http://techmaster-preview-com.3dcartstores.com/rss.asp?type=bestsellers" />
<link rel="alternate" type="application/rss+xml" title="Latest Blog Posts (RSS 2.0)" href="http://techmaster-preview-com.3dcartstores.com/rss.asp?type=blog" />
<!--END: FRAME_RSSFEEDS -->
<link rel="stylesheet" href="bootstrap.css">
<script type="text/javascript">
function validateForm() {
    var x = document.forms["myForm"]["email"].value;
    var atpos = x.indexOf("@");
    var dotpos = x.lastIndexOf(".");
    if (atpos<1 || dotpos<atpos+2 || dotpos+2>=x.length) {
        alert("Not a valid e-mail address");
        return false;
    }
}
    if (typeof jQuery == 'undefined') {
        document.write("<script type=\"text/javascript\" src=\"/assets/templates/common-html5/js/jquery.min.js?vcart=7.2.0\"></" + "script>");
    }
</script>
<link media="screen" rel="stylesheet" href="/assets/templates/common-html5/js/quick_view.css?vcart=7.2.0" />
<style>
    li{
        list-style-type: none;
    }
    #FRAME_SEARCH{
        padding: 40px 0px;        
    }
    #homeCarousel{
    }
    #grad {
    min-height: 400px;
    width: 100%;
    background: linear-gradient(141deg, #0fb8ad 0%, #1fc8db 51%, #2cb5e8 75%);
    color: white;
    opacity: 0.95;
    }
</style>
<script src="/assets/templates/common-html5/js/quick_view.js?vcart=7.2.0" type="text/javascript"></script>
<script src="/assets/templates/common-html5/js/jquery.simplemodal.min.js?vcart=7.2.0" type="text/javascript"></script>
</head><body>
<!--<div class="top-menu">
    <div class="wrapper">         
    <a id="mobileMenu" class="show-mobile"><i class="icon-ellipsis-vert"></i></a>
    <a href="view_cart.asp" id="mobileCart" class="show-mobile"><i class="icon-basket"></i></a>
    <span class="greeting"><img src="assets/templates/techmaster-html5/images/phone.png" alt="">   | <img src="assets/templates/techmaster-html5/images/person.png" alt="">  <!--START: loginWelcome, <span>Guest</span> <span class="bullet">&bull;</span> <a href="myaccount.asp">Login</a><!--END: login--><!--START: username--><!--END: username  | <img src="assets/templates/techmaster-html5/images/shopping-cart-white.png" alt="">  <a href="/view_cart.asp">View Cart</a></span>
   <!-- <nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left" id="showSlideMenu">
      <a id="closeSlideMenu" class="show-mobile"><i class="icon-cancel-circled"></i></a>
      <ul>
        <li class="m-search show-mobile">
          <div>
            <form method="get" name="mSearchForm" action="search.asp">
              <input type="text" name="keyword" value="" placeholder="Search" />
              <button name="search"><i class="icon-search"></i></button>
              <div class="clear"></div>
            </form>
          </div>
        </li>        
        <div id="FRAME_MENU" >--><!--START: FRAME_MENU-->
          <!--START: menuitems_view-->          
          <!--<li><a href="About-Us_ep_7.html" class="menu" target="_self">About Us</a></li>
                    
          <li><a href="myaccount.asp" class="menu" target="_self">My Account</a></li>
                    
          <li><a href="crm.asp?action=contactus" class="menu" target="_self">Contact Us</a></li>
                    
          <li><a href="blog.asp" class="menu" target="_self">Help</a></li>
          <!--END: menuitems_view-->
        <!--END: FRAME_MENU--><!--</div>
        <div id="MOBILE-MENU">
        </div>
      </ul>
      <div class="clear"></div>
      </nav>
        <div class="clear"></div>
    </div>
</div>-->
<div id="mainContainer">
  <header>
    <div class="wrapper">
      <div id="logo">
            <h1>Bid-o-Bid</h1>
      </div>
        <div id="cart-area">
        </div>        
        <div id="FRAME_SEARCH" ><!--START: FRAME_SEARCH-->        
          <div class="hidden-mobile">
            <form method="POST"  action="login.php" class="form-inline">
                <input type="text" name="username" placeholder="Username" class="form-control">
                <input type="password" name="password" placeholder="Password" class="form-control">
                <button name="login">Login</button>
            </form>
            <div class="clear"></div>
          </div>
        <!--END: FRAME_SEARCH--></div>
    </div>
  </header>
  <!--<div id="slidebg"></div>-->
  <div id="mobilewrap">
    <div class="wrapper"></div>
  </div>
  <div class="wrapper" style="padding:0; margin:0; width: 100%;">

    <!--START: LEFT BAR-->
    <aside id="leftBar" class="leftBar">
      <div class="column" id="column1"> 
        <!--START: LEFT_BAR_BLOCKS-->

          <!--START: FRAME_MANUFACTURER--><!--END: FRAME_MANUFACTURER-->        

        <!--START: LEFT_BANNER--><!--END: LEFT_BANNER--> 
        <!--END: LEFT_BAR_BLOCKS--> 
      </div>
    </aside>
    <!--END: LEFT BAR-->

  <div id="mainContent"><section id="home">
<!--START: home_carousel-->
<link rel="stylesheet" href="/assets/templates/common-html5/css/flexslider.css?vcart=7.2.0" type="text/css" media="screen" />
<script type="text/javascript" src="/assets/templates/common-html5/js/jquery.flexslider-min.js?vcart=7.2.0"></script>
<div id="grad" class="container">
<div class="col-md-6 col-xs-12">
    <img src="assets/images/infographic.png" alt="">
</div>
<div class="col-md-6 col-xs-12">



<h2>SIGN UP!</h2><br>
<form action="signup.php" method="POST" onsubmit="return validateForm();">
    <div class="form-inline">
        <input type="text" name="first_name" placeholder="First Name" class="form-control" required>
        <input type="text" name="last_name" placeholder="Last Name" class="form-control" required>
        <br><br>
    </div>
    <div class="form-inline">
        <input type="text" name="user_name" placeholder="Choose Username" class="form-control" required>
        <input type="password" name="password" placeholder="Password" class="form-control" required>
        <br><br>
    </div>
    <div class="form-inline">
        <input type="text" name="email" placeholder="Email" class="form-control" required>
        <input type="number" name="mobile" placeholder="Mobile" class="form-control" required min="1000000000" max="9999999999">
    </div>
    <br>
    <input type="checkbox">
     I accept the Terms and Conditions and the Privacy Policy of Bid-o-Bid.
     <br><br>
    <button name="signup">Signup</button>
	
</form>
</div>
</div>



<script type="text/javascript" charset="utf-8">
    jQuery(document).ready(function () {
        jQuery('#homeCarousel').flexslider({
            animation: "fade",
            slideshowSpeed: 4000,
            controlNav: false,
            keyboard: false
        });
    });
</script>
<!--END: home_carousel-->
<!--START: CATEGORY_HEADER--><!--END: CATEGORY_HEADER--> 
<!--START: FEATURE_MENU-->
<h2 class="header-specials">Featured Products</h2>
<!--START: CATEGORY_ITEMS--><div class="productBlockContainer columns-3"><div class="product-container first-item"> 
<div class="product-item alternative">
    <div class="img"><a href="50-Flat-Screen-TV_p_1.html"><img src="assets/images/p1_thumbnail.jpg" alt="50" Flat Screen TV" id="qv_1" /></a></div>
    <div class="name"><a href="50-Flat-Screen-TV_p_1.html">50" Flat Screen TV</a></div>
    <div class="stars">
    <!--START: product_review--> 
    <!--START: product_review_average-->
        <img src="assets/templates/common-html5/images/star5.png" alt="Average Rating" /><span>(1)</span>
        <div class="clear"></div>
    <!--END: product_review_average--> 
    <!--END: product_review-->
    </div>
    <div class="price"><!--START: ITEMPRICE--><!--END: ITEMPRICE--> 
    <!--START: SALEPRICE-->
    <del class="price2">$19.99&nbsp;</del>
    <span class="hidden">On sale:&nbsp;</span>$16.99
    <div class="on-sale">Sale</div>
    <!--END: SALEPRICE--></div>
    <div class="status"><!--START: product_availability-->In Stock. <!--END: product_availability--><!--START: freeshippingblock-->Free Shipping.<!--END: freeshippingblock--></div>
    <div class="action">
        <input type="button" value="Add To Cart" class="btn btn-default" />
    </div>
    <div class="clear"></div>
</div>
</div><div class="product-container middle-item"> 
<div class="product-item alternative">
    <div class="img"><a href="Desktop-Fans_p_2.html"><img src="assets/images/p2_thumbnail.jpg" alt="Desktop Fans" id="qv_2" /></a></div>
    <div class="name"><a href="Desktop-Fans_p_2.html">Desktop Fans</a></div>
    <div class="stars">
    <!--START: product_review--> 
    <!--START: product_review_average-->
        <img src="assets/templates/common-html5/images/star0.png" alt="Average Rating" /><span>(0)</span>
        <div class="clear"></div>
    <!--END: product_review_average--> 
    <!--END: product_review-->
    </div>
    <div class="price"><!--START: ITEMPRICE--> 
    <span class="hidden">Your Price:&nbsp;</span>$24.99
    <!--END: ITEMPRICE--> 
    </div>
    <div class="status"><!--START: product_availability-->In Stock. <!--END: product_availability--><!--START: freeshippingblock--><!--END: freeshippingblock--></div>
    <div class="action">
        <input type="button" value="Add To Cart" class="btn btn-default" />
    </div>
    <div class="clear"></div>
</div>
</div><div class="product-container last-item"> 
<div class="product-item alternative">
    <div class="img"><a href="iPad-Air_p_4.html"><img src="assets/images/p4_thumbnail.jpg" alt="iPad Air" id="qv_4" /></a></div>
    <div class="name"><a href="iPad-Air_p_4.html">iPad Air</a></div>
    <div class="stars">
    <!--START: product_review--> 
    <!--START: product_review_average-->
        <img src="assets/templates/common-html5/images/star0.png" alt="Average Rating" /><span>(0)</span>
        <div class="clear"></div>
    <!--END: product_review_average--> 
    <!--END: product_review-->
    </div>
    <div class="price"><!--START: ITEMPRICE--> 
    <span class="hidden">Your Price:&nbsp;</span>$14.99
    <!--END: ITEMPRICE--> 
    </div>
    <div class="status"><!--START: product_availability-->In Stock. <!--END: product_availability--><!--START: freeshippingblock-->Free Shipping.<!--END: freeshippingblock--></div>
    <div class="action">
        <input type="button" value="Add To Cart" class="btn btn-default" />
    </div>
    <div class="clear"></div>
</div>
</div><div style="clear: both;"></div></div><div class="productBlockContainer columns-3"><div class="product-container first-item"> 
<div class="product-item alternative">
    <div class="img"><a href="Samsung-Digital-Camera_p_3.html"><img src="assets/images/p3_thumbnail.jpg" alt="Samsung Digital Camera" id="qv_3" /></a></div>
    <div class="name"><a href="Samsung-Digital-Camera_p_3.html">Samsung Digital Camera</a></div>
    <div class="stars">
    <!--START: product_review--> 
    <!--START: product_review_average-->
        <img src="assets/templates/common-html5/images/star0.png" alt="Average Rating" /><span>(0)</span>
        <div class="clear"></div>
    <!--END: product_review_average--> 
    <!--END: product_review-->
    </div>
    <div class="price"><!--START: ITEMPRICE--> 
    <span class="hidden">Your Price:&nbsp;</span>$76.99
    <!--END: ITEMPRICE--> 
    </div>
    <div class="status"><!--START: product_availability-->Ships in 24hrs <!--END: product_availability--><!--START: freeshippingblock-->Free Shipping.<!--END: freeshippingblock--></div>
    <div class="action">
        <input type="button" value="Add To Cart" class="btn btn-default" />
    </div>
    <div class="clear"></div>
</div>
</div><div class="product-container middle-item"> 
<div class="product-item alternative">
    <div class="img"><a href="Sony-PS4_p_7.html"><img src="assets/images/p8_thumbnail.jpg" alt="Sony PS4" id="qv_7" /></a></div>
    <div class="name"><a href="Sony-PS4_p_7.html">Sony PS4</a></div>
    <div class="stars">
    <!--START: product_review--> 
    <!--START: product_review_average-->
        <img src="assets/templates/common-html5/images/star5.png" alt="Average Rating" /><span>(1)</span>
        <div class="clear"></div>
    <!--END: product_review_average--> 
    <!--END: product_review-->
    </div>
    <div class="price"><!--START: ITEMPRICE--> 
    <span class="hidden">Your Price:&nbsp;</span>$3.99
    <!--END: ITEMPRICE--> 
    </div>
    <div class="status"><!--START: product_availability-->In Stock. <!--END: product_availability--><!--START: freeshippingblock--><!--END: freeshippingblock--></div>
    <div class="action">
        <input type="button" value="Add To Cart" class="btn btn-default" />

    </div>
    <div class="clear"></div>
</div>
</div><div class="product-container last-item"> 
<div class="product-item alternative">
    <div class="img"><a href="VHS-to-DVD-Converter_p_5.html"><img src="assets/images/p5_thumbnail.jpg" alt="VHS to DVD Converter" id="qv_5" /></a></div>
    <div class="name"><a href="VHS-to-DVD-Converter_p_5.html">VHS to DVD Converter</a></div>
    <div class="stars">
    <!--START: product_review--> 
    <!--START: product_review_average-->
        <img src="assets/templates/common-html5/images/star0.png" alt="Average Rating" /><span>(0)</span>
        <div class="clear"></div>
    <!--END: product_review_average--> 
    <!--END: product_review-->
    </div>
    <div class="price"><!--START: ITEMPRICE--> 
    <span class="hidden">Your Price:&nbsp;</span>$34.99
    <!--END: ITEMPRICE--> 
    </div>
    <div class="status"><!--START: product_availability-->In Stock. <!--END: product_availability--><!--START: freeshippingblock-->Free Shipping.<!--END: freeshippingblock--></div>
    <div class="action">

        <input type="button" value="Add To Cart" class="btn btn-default" />
    </div>
    <div class="clear"></div>
</div>
</div><div style="clear: both;"></div></div><!--END: CATEGORY_ITEMS--> 
<!--END: FEATURE_MENU-->
<div class="clear"></div>
<!--START: CATEGORY_FOOTER--><!--END: CATEGORY_FOOTER-->
</section>
</div>
    <!--START: RIGHT BAR--><!--START: FRAME_CATEGORY--><!--END: FRAME_CATEGORY--><!--END: RIGHT BAR-->
  <div class="clear"></div>
  </div>
  <footer>
    <div class="wrapper"> 
      <div class="ftr-col col1">
      <div id="FRAME_LINKS" ><!--START: FRAME_LINKS-->
      <div id="modLinks">
          <h3>Links</h3>
          <ul class="frame-links">
            <!--START: LINKS-->
            <li><a href="blog.asp" target="_self" class="menu-bottom">Blog</a></li>
            
            <li><a href="Terms-and-Conditions_ep_2-1.html" target="_self" class="menu-bottom">Terms and Conditions</a></li>
            
            <li><a href="affiliateInfo.asp" target="_self" class="menu-bottom">Become an Affiliate</a></li>
            
            <li><a href="product_index.asp" target="_self" class="menu-bottom">Product Index</a></li>
            
            <li><a href="category_index.asp" target="_self" class="menu-bottom">Category Index</a></li>
            <!--END: LINKS-->
          </ul>
      </div>
      <!--END: FRAME_LINKS--></div> 
      </div>
      <div class="ftr-col col3">
      <!--START: FRAME_MAILLIST-->
      <div id="mailistBox">
        <form method="post" name="mailing" action="https://techmaster-preview-com.3dcartstores.com/mailing_list.asp?action=add" onsubmit="return mailing_list();">
          <label>Mailing List</label>
          <div class="mailist-box">
            <input type="text" name="email" value="" placeholder="Email Address" />
            <input type="submit" name="www" value="GO" />
            <div class="clear"></div>
          </div>
          <input type="radio" name="subscribe" value="1" checked="checked" />
          <span class="menu-text">Subscribe</span>
          <input type="radio" name="subscribe" value="0" />
          <span class="menu-text">Unsubscribe</span>
          <div class="clear"></div>
        </form>
        <div class="clear"></div>
      </div>
      <!--END: FRAME_MAILLIST-->
      <div class="clear"></div> 
      </div>
      <div class="clear"></div>
      <div id="globalFooter" class="footer"></div>
      <div class="clear"></div>     
    </div>
  </footer>
  <div id="copyright" class="footer">
    <div class="wrapper">Copyright  <script type="text/javascript" language="javascript">var date = new Date(); document.write(date.getFullYear())</script> Sample Store. All Rights Reserved. eCommerce Software by <a href="http://www.3dcart.com">3dcart</a>.</div>
  </div>   
</div>


<!--START: quicksearch--> 
<script type="text/javascript" src="assets/templates/common-html5/quicksearch/jquery.quicksearch.js?vcart=7.2.0"></script> 
<script type="text/javascript">
/*jQuery(function() {
	jQuery('#searchlight').searchlight('/search_quick.asp');
});*/
</script> 
<!--END: quicksearch--> 
<script type="text/javascript" src="assets/templates/techmaster-html5/js/functions.js?vcart=7.2.0"></script>
<script type="text/javascript">
/*jQuery(document).ready(function () {
    jQuery('#desktopMenu').slicknav({
        prependTo: '.top-menu .wrapper',
        label: '',
        allowParentLinks: true,
        closedSymbol: '',
        openedSymbol: ''
    });
});*/
</script>
<div class="stats"> 
  <!--START: 3dcart stats--> 
  <script type="text/javascript">
//<![CDATA[
var file='/stats/count.asp';

var stats_d=new Date();
var stats_s=stats_d.getSeconds();
var stats_m=stats_d.getMinutes();
var stats_x=stats_s*stats_m;
var prdID = '[catalogid]';
var catID = '[catid]';

stats_f='' + escape(document.referrer); stats_f=stats_f.replace('_','----');
if (navigator.appName=='Netscape'){stats_b='NS';}
if (navigator.appName=='Microsoft Internet Explorer'){stats_b='MSIE';}
if (navigator.appVersion.indexOf('MSIE 3')>0) {stats_b='MSIE';}
stats_u='' + escape(document.URL); stats_u=stats_u.replace('_','----'); stats_w=screen.width; stats_h=screen.height;
stats_v=navigator.appName;
stats_fs = window.screen.fontSmoothingEnabled;
if (stats_v != 'Netscape') {stats_c=screen.colorDepth;}
else {stats_c=screen.pixelDepth;}
stats_j=navigator.javaEnabled();
info='w=' + stats_w + '&h=' + stats_h + '&c=' + stats_c + '&r=' + stats_f + '&u='+ stats_u + '&fs=' + stats_fs + '&b=' + stats_b + '&x=' + stats_x + '&cat=' + catID + '&prd=' + prdID;
document.write('<img src="' + file + '?'+info+ '" width="1" height="1" border="0" alt="stats" />');
//]]>
</script>
  <noscript>
  <img src="/stats/count.asp" width="90" height="30" alt="" />
  </noscript>
  <!--END: 3dcart stats--> 
</div>
<div id="qv_buttontitle" style="display:none;">Quick View</div>
<script>(new Image()).src = 'http://techmaster-preview-com.3dcartstores.com/3dvisit.asp'</script></body>
</html>
