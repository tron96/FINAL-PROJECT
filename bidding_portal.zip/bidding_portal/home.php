<?php
	session_start(); 
    //Session based login set
    if (!isset($_SESSION['username'])) {
        header("Location: index.php");
    }
?>

<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js">
<!--<![endif]-->
<head>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>Welcome to Sample Store  - Sample Slogan</title>
<link rel="canonical" href="http://techmaster-preview-com.3dcartstores.com" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0" />
<script type="text/javascript" src="assets/templates/common-html5/js/modernizr.min.js?vcart=7.2.0"></script>
<script type="text/javascript" src="assets/templates/common-html5/js/utilities.js?vcart=7.2.0"></script>
<script type="text/javascript" src="assets/templates/common-html5/js/jquery.min.js"></script>
<script type="text/javascript" src="assets/templates/common-html5/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="assets/templates/common-html5/quicksearch/quicksearch.css?vcart=7.2.0" type="text/css" media="screen" />
<link rel="stylesheet" href="assets/templates/common-html5/css/layout.css?vcart=7.2.0" type="text/css" media="all" />
<link rel="stylesheet" href="assets/templates/common-html5/css/responsive.css?vcart=7.2.0" type="text/css" media="screen" />
<link rel="stylesheet" href="assets/templates/techmaster-html5/css/default.css?vcart=7.2.0" type="text/css" media="screen" />
<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700' rel='stylesheet' type='text/css' />
<link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,300,700' rel='stylesheet' type='text/css' />
<link rel="stylesheet" href="assets/templates/common-html5/css/fontello.css?vcart=7.2.0" />
<!--[if IE 7]>
<link rel="stylesheet" href="assets/templates/common-html5/css/fontello-ie7.css?vcart=7.2.0" />
<![endif]-->
<!--START: FRAME_RSSFEEDS -->
<link rel="alternate" type="application/rss+xml" title="Featured Items (RSS 2.0)" href="http://techmaster-preview-com.3dcartstores.com/rss.asp?type=home" />
<link rel="alternate" type="application/rss+xml" title="Products On Sale (RSS 2.0)" href="http://techmaster-preview-com.3dcartstores.com/rss.asp?type=onsale" />
<link rel="alternate" type="application/rss+xml" title="New Releases (RSS 2.0)" href="http://techmaster-preview-com.3dcartstores.com/rss.asp?type=newreleases" />
<link rel="alternate" type="application/rss+xml" title="Best Sellers (RSS 2.0)" href="http://techmaster-preview-com.3dcartstores.com/rss.asp?type=bestsellers" />
<link rel="alternate" type="application/rss+xml" title="Latest Blog Posts (RSS 2.0)" href="http://techmaster-preview-com.3dcartstores.com/rss.asp?type=blog" />
<!--END: FRAME_RSSFEEDS -->
<link rel="stylesheet" href="bootstrap.css">
<script type="text/javascript">
    if (typeof jQuery == 'undefined') {
        document.write("<script type=\"text/javascript\" src=\"/assets/templates/common-html5/js/jquery.min.js?vcart=7.2.0\"></" + "script>");
    }
</script>
<link media="screen" rel="stylesheet" href="/assets/templates/common-html5/js/quick_view.css?vcart=7.2.0" />
<style>
    li{
        list-style-type: none;
    }
    #FRAME_SEARCH{
        padding: 40px 0px;        
    }
    #homeCarousel{
    }
    #grad {
    min-height: 400px;
    width: 100%;
    background: linear-gradient(141deg, #0fb8ad 0%, #1fc8db 51%, #2cb5e8 75%);
    color: white;
    opacity: 0.95;
    }
</style>
<script src="/assets/templates/common-html5/js/quick_view.js?vcart=7.2.0" type="text/javascript"></script>
<script src="/assets/templates/common-html5/js/jquery.simplemodal.min.js?vcart=7.2.0" type="text/javascript"></script>
</head><body>
<!--<div class="top-menu">
    <div class="wrapper">         
    <a id="mobileMenu" class="show-mobile"><i class="icon-ellipsis-vert"></i></a>
    <a href="view_cart.asp" id="mobileCart" class="show-mobile"><i class="icon-basket"></i></a>
    <span class="greeting"><img src="assets/templates/techmaster-html5/images/phone.png" alt="">   | <img src="assets/templates/techmaster-html5/images/person.png" alt="">  <!--START: loginWelcome, <span>Guest</span> <span class="bullet">&bull;</span> <a href="myaccount.asp">Login</a><!--END: login--><!--START: username--><!--END: username  | <img src="assets/templates/techmaster-html5/images/shopping-cart-white.png" alt="">  <a href="/view_cart.asp">View Cart</a></span>
   <!-- <nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left" id="showSlideMenu">
      <a id="closeSlideMenu" class="show-mobile"><i class="icon-cancel-circled"></i></a>
      <ul>
        <li class="m-search show-mobile">
          <div>
            <form method="get" name="mSearchForm" action="search.asp">
              <input type="text" name="keyword" value="" placeholder="Search" />
              <button name="search"><i class="icon-search"></i></button>
              <div class="clear"></div>
            </form>
          </div>
        </li>        
        <div id="FRAME_MENU" >--><!--START: FRAME_MENU-->
          <!--START: menuitems_view-->          
          <!--<li><a href="About-Us_ep_7.html" class="menu" target="_self">About Us</a></li>
                    
          <li><a href="myaccount.asp" class="menu" target="_self">My Account</a></li>
                    
          <li><a href="crm.asp?action=contactus" class="menu" target="_self">Contact Us</a></li>
                    
          <li><a href="blog.asp" class="menu" target="_self">Help</a></li>
          <!--END: menuitems_view-->
        <!--END: FRAME_MENU--><!--</div>
        <div id="MOBILE-MENU">
        </div>
      </ul>
      <div class="clear"></div>
      </nav>
        <div class="clear"></div>
    </div>
</div>-->
<div id="mainContainer">
  <!--<header>
    <div class="container row">
        <div class="col-md-6" id="log">
            
            <h1>Bid-o-Bid</h1>

        </div>
        <div class="col-md-6">
              
        </div>
    </div>
  </header>-->
<!--  <header>
    <div class="wrapper">
      <div id="logo">
            <h1>Bid-o-Bid</h1>
      </div>
        <div id="cart-area">
        </div>        
        <div id="FRAME_SEARCH" >
          <div class="hidden-mobile">
            <form method="POST"  action="login.php" class="form-inline">
                <input type="text" name="username" placeholder="Username" class="form-control">
                <input type="password" name="password" placeholder="Password" class="form-control">
                <button name="login">Login</button>
            </form>
            <div class="clear"></div>
          </div>
        </div>
    </div>
  </header>-->
<header>
    <div class="wrapper" style="padding: 30px;">
        <div class="col-md-6 h1">Bid-o-Bid</div>
        <div class="col-md-6 pull-right" style="text-align: right;"><br>
            <div class="dropdown pull-right">
          <button class="btn btn-danger dropdown-toggle" type="button" data-toggle="dropdown">
            Welcome, <?php echo $_SESSION['username'];?>
          <span class="caret"></span></button>
          <ul class="dropdown-menu">
            <li><a href="#">HTML</a></li>
            <li><a href="#">CSS</a></li>
            <li><a href="#">JavaScript</a></li>
			<li><a href="insert_product_details.php">Insert product Details</a></li>
          </ul>
        </div>
        </div>
    </div>
</header>

  <!--<div id="slidebg"></div>-->
  <div id="mobilewrap">
    <div class="wrapper"></div>
  </div>
  <div class="wrapper" style="padding:0; margin:0; width: 100%;">

    <!--START: LEFT BAR-->
    <aside id="leftBar" class="leftBar">
      <div class="column" id="column1"> 
        <!--START: LEFT_BAR_BLOCKS-->

          <!--START: FRAME_MANUFACTURER--><!--END: FRAME_MANUFACTURER-->        

        <!--START: LEFT_BANNER--><!--END: LEFT_BANNER--> 
        <!--END: LEFT_BAR_BLOCKS--> 
      </div>
    </aside>
    <!--END: LEFT BAR-->
<script type="text/javascript" charset="utf-8">
    jQuery(document).ready(function () {
        jQuery('#homeCarousel').flexslider({
            animation: "fade",
            slideshowSpeed: 4000,
            controlNav: false,
            keyboard: false
        });
    });
</script>
<!--END: home_carousel-->
<!--START: CATEGORY_HEADER--><!--END: CATEGORY_HEADER--> 
<!--START: FEATURE_MENU-->
 <div class="starter-template">
        <h1>Welcome, <?php echo $_SESSION['username'];?></h1>
        <p class="lead">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Possimus, voluptatem unde vitae voluptas quaerat aliquid, facilis, totam iste obcaecati natus officia, vel quasi sit eos! Alias earum aperiam provident, est!</p>
      </div>
<h2 class="header-specials">Featured Products</h2>
<!--START: CATEGORY_ITEMS--><div class="productBlockContainer columns-3">
<?php
require 'config.php';
$que="select * from product_table WHERE 1;";
	$run=mysqli_query($con,$que);
	if (!$run) {
			echo "Error: " . mysqli_error($con);
		}
	while($row=mysqli_fetch_array($run))
	{
		//echo $row['product_name']+" - "+$row['product_id']+" - "+$row['base_price']+" - "+$row['shipping_price']+"<br>";
		$product_name = $row['product_name'];
		$product_id = $row['product_id'];
		$base_price= $row['base_price'];
		$shipping_price = $row['shipping_price'];
		$que1="select * from image_table WHERE `product_id`=".$product_id.";";
		$link="product_details.php?id=".$product_id;
		$run1=mysqli_query($con,$que1);
		if (!$run1) {
				echo "Error: " . mysqli_error($con);
			}	
		$row1=mysqli_fetch_array($run1);
		$loc=$row1['image_location'];
		echo '<div class="product-container middle-item">'; 
			echo '<div class="product-item alternative">';
				echo '<div class="img"><a href="'.$link.'">'.'<img src="'.$loc.'" alt="'.$product_name.'" id="qv_2" /></a></div>';
				echo '<div class="name"><a href="'.$link.'">'.$product_name.'</a></div>';
				
				echo '<div class="stars">';
				echo '<!--START: product_review-->'; 
				echo '<!--START: product_review_average-->';
					echo '<img src="assets/templates/common-html5/images/star0.png" alt="Average Rating" /><span>(0)</span>';
					echo '<div class="clear"></div>';
				echo '<!--END: product_review_average-->'; 
				echo '<!--END: product_review-->';
				echo '</div>';
				echo '<div class="price"><!--START: ITEMPRICE-->'; 
				echo '<span class="hidden">Your Price:&nbsp;</span>Rs. '.$base_price;
				echo '<!--END: ITEMPRICE-->'; 
				echo '</div>';
				echo '<div class="status"><!--START: product_availability-->In Stock. <!--END: product_availability--><!--START: freeshippingblock--><!--END: freeshippingblock--></div>';
				echo '<div class="action">';
					echo '<input type="button" value="Add To Cart" class="btn btn-default" />';
				echo '</div>';
				echo '<div class="clear"></div>';
			echo '</div>';
		echo '</div>';
	}
?>

<div style="clear: both;"></div></div><!--END: CATEGORY_ITEMS--> 
<!--END: FEATURE_MENU-->
<div class="clear"></div>
<!--START: CATEGORY_FOOTER--><!--END: CATEGORY_FOOTER-->
</section>
</div>
    <!--START: RIGHT BAR--><!--START: FRAME_CATEGORY--><!--END: FRAME_CATEGORY--><!--END: RIGHT BAR-->
  <div class="clear"></div>
  </div>
  <footer>
    <div class="wrapper"> 
      <div class="ftr-col col1">
      <div id="FRAME_LINKS" ><!--START: FRAME_LINKS-->
      <div id="modLinks">
          <h3>Links</h3>
          <ul class="frame-links">
            <!--START: LINKS-->
            <li><a href="blog.asp" target="_self" class="menu-bottom">Blog</a></li>
            
            <li><a href="Terms-and-Conditions_ep_2-1.html" target="_self" class="menu-bottom">Terms and Conditions</a></li>
            
            <li><a href="affiliateInfo.asp" target="_self" class="menu-bottom">Become an Affiliate</a></li>
            
            <li><a href="product_index.asp" target="_self" class="menu-bottom">Product Index</a></li>
            
            <li><a href="category_index.asp" target="_self" class="menu-bottom">Category Index</a></li>
            <!--END: LINKS-->
          </ul>
      </div>
      <!--END: FRAME_LINKS--></div> 
      </div>
      <div class="ftr-col col3">
      <!--START: FRAME_MAILLIST-->
      <div id="mailistBox">
        <form method="post" name="mailing" action="https://techmaster-preview-com.3dcartstores.com/mailing_list.asp?action=add" onsubmit="return mailing_list();">
          <label>Mailing List</label>
          <div class="mailist-box">
            <input type="text" name="email" value="" placeholder="Email Address" />
            <input type="submit" name="www" value="GO" />
            <div class="clear"></div>
          </div>
          <input type="radio" name="subscribe" value="1" checked="checked" />
          <span class="menu-text">Subscribe</span>
          <input type="radio" name="subscribe" value="0" />
          <span class="menu-text">Unsubscribe</span>
          <div class="clear"></div>
        </form>
        <div class="clear"></div>
      </div>
      <!--END: FRAME_MAILLIST-->
      <div class="clear"></div> 
      </div>
      <div class="clear"></div>
      <div id="globalFooter" class="footer"></div>
      <div class="clear"></div>     
    </div>
  </footer>
  <div id="copyright" class="footer">
    <div class="wrapper">Copyright  <script type="text/javascript" language="javascript">var date = new Date(); document.write(date.getFullYear())</script> Sample Store. All Rights Reserved. eCommerce Software by <a href="http://www.3dcart.com">3dcart</a>.</div>
  </div>   
</div>


<!--START: quicksearch--> 
<script type="text/javascript" src="assets/templates/common-html5/quicksearch/jquery.quicksearch.js?vcart=7.2.0"></script> 
<script type="text/javascript">
/*jQuery(function() {
	jQuery('#searchlight').searchlight('/search_quick.asp');
});*/
</script> 
<!--END: quicksearch--> 
<script type="text/javascript" src="assets/templates/techmaster-html5/js/functions.js?vcart=7.2.0"></script>
<script type="text/javascript">
/*jQuery(document).ready(function () {
    jQuery('#desktopMenu').slicknav({
        prependTo: '.top-menu .wrapper',
        label: '',
        allowParentLinks: true,
        closedSymbol: '',
        openedSymbol: ''
    });
});*/
</script>
<div class="stats"> 
  <!--START: 3dcart stats--> 
  <script type="text/javascript">
//<![CDATA[
var file='/stats/count.asp';

var stats_d=new Date();
var stats_s=stats_d.getSeconds();
var stats_m=stats_d.getMinutes();
var stats_x=stats_s*stats_m;
var prdID = '[catalogid]';
var catID = '[catid]';

stats_f='' + escape(document.referrer); stats_f=stats_f.replace('_','----');
if (navigator.appName=='Netscape'){stats_b='NS';}
if (navigator.appName=='Microsoft Internet Explorer'){stats_b='MSIE';}
if (navigator.appVersion.indexOf('MSIE 3')>0) {stats_b='MSIE';}
stats_u='' + escape(document.URL); stats_u=stats_u.replace('_','----'); stats_w=screen.width; stats_h=screen.height;
stats_v=navigator.appName;
stats_fs = window.screen.fontSmoothingEnabled;
if (stats_v != 'Netscape') {stats_c=screen.colorDepth;}
else {stats_c=screen.pixelDepth;}
stats_j=navigator.javaEnabled();
info='w=' + stats_w + '&h=' + stats_h + '&c=' + stats_c + '&r=' + stats_f + '&u='+ stats_u + '&fs=' + stats_fs + '&b=' + stats_b + '&x=' + stats_x + '&cat=' + catID + '&prd=' + prdID;
document.write('<img src="' + file + '?'+info+ '" width="1" height="1" border="0" alt="stats" />');
//]]>
</script>
  <noscript>
  <img src="/stats/count.asp" width="90" height="30" alt="" />
  </noscript>
  <!--END: 3dcart stats--> 
</div>
<div id="qv_buttontitle" style="display:none;">Quick View</div>
<script>(new Image()).src = 'http://techmaster-preview-com.3dcartstores.com/3dvisit.asp'</script></body>
</html>
