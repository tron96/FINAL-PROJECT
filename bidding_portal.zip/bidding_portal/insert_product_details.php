<?php
	session_start(); 
    //Session based login set
    if (!isset($_SESSION['username'])) {
        header("Location: index.php");
    }
?>
<html>
<head>

<style>
body {
    background-color:#E6E6E6;
}


</style>

</head>

<body>
<center>
<br>
<form method="POST" action="add_product.php" enctype='multipart/form-data'>
<table width="400" border="0" cellspacing="1" cellpadding="2">
<caption>
<h3>Add Product</h3>
</caption><br><br><br><br>
<tr>
<td width="100">Product Name</td>
<td><input name="product_name" type="text" id="product_name"></td>
</tr>
<tr>
<td width="100">Base Price</td>
<td><input name="base_price" type="text" id="base_price"></td>
</tr>
<tr>
<td width="100">Shipping Price</td>
<td><input name="shipping_price" type="text" id="shipping_price"></td>
</tr>
<tr>
<td width="100">Bid Reset Time</td>
<td><input name="bid_reset_time" type="number" id="bid_reset_time"></td>
</tr>
<tr>
<td width="100">Bid Start Time</td>
<td><input name="bid_start_time" type="datetime-local" id="bid_start_time"></td>
</tr>
<tr>
<td width="100">Bid End Time</td>
<td><input name="bid_end_time" type="datetime-local" id="bid_end_time"></td>
</tr>
<tr>
<td width="100">Credits Used per Bid</td>
<td><input name="credits_used_per_bid" type="text" id="credits_used_per_bid"></td>
</tr>


<tr>
<td>Product Description</td>
<td><textarea name="product_description" rows="4" cols="30"></textarea></td></td>
</tr>
<tr>
<td width="100">Select image to upload:</td>
<td width="100">    <input type="file" name="fileToUpload" id="fileToUpload">   
</td>
</tr>
<tr>
<td width="100"> </td>
<td> </td>
</tr>
<tr>
<td width="100"> </td>
<td>
<input name="add" type="submit" id="add" value="add product detail">
</td>
</tr>
</table>
</form>
</center>
</body>
</html>