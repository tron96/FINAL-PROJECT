 <html>
<head>
<style>
body {
    background-color:#E6E6E6;
}


</style>

</head>
<body>
<center>
<br>
<br><br><br><br>
<?php

require 'config.php';

if(isset($_POST['add']))
{


$product_name = $_POST['product_name'];
$base_price = $_POST['base_price'];
$shipping_price= $_POST['shipping_price'];
$bid_reset_time = $_POST['bid_reset_time'];
$bid_start_time = $_POST['bid_start_time'];
$bid_end_time = $_POST['bid_end_time'];
$credits_used_per_bid = $_POST['credits_used_per_bid'];
$product_description = $_POST['product_description'];




if($product_name=="" || $base_price=="" || $shipping_price=="" || $bid_reset_time=="" || $bid_start_time=="" || $bid_end_time=="" || $credits_used_per_bid=="" || $product_description=="")
{
	header('location:insert_product_details.php?message=Please fill completely.');
}
else{
$sql = "INSERT INTO `product_table`(`product_name`, `product_description`, `base_price`, `shipping_price`, `bid_reset_time`, `bid_start_time`, `bid_end_time`, `credits_used_per_bid`, `winner_id`) 
VALUES ('".$product_name."','".$product_description."',".$base_price.",".$shipping_price.",".$bid_reset_time.",'".$bid_start_time."','".$bid_end_time."',".$credits_used_per_bid.",1);";

if (mysqli_query($con,$sql)) {

$loc = getcwd()."\\product_images\\".$_FILES['fileToUpload']['name'];
move_uploaded_file( $_FILES['fileToUpload']['tmp_name'], $loc);
$loc1 = "http://localhost/bidding_portal/product_images/".$_FILES['fileToUpload']['name'];
$sql = "INSERT INTO `image_table`(`product_id`, `image_location`) VALUES (LAST_INSERT_ID(), '".$loc1."')";
//echo $sql."<br>";
if(mysqli_query($con,$sql)){	
echo "Product Details successfully \entered<br><br>
<a href=home.php><button>Go Back Home</button></a>";
} else {
	echo "Error: " . mysqli_error($con)."<br><br>
	<a href=insert_product_details.php><button>Enter New Product Details</button></a>";
}
} else {
echo "Error: " . mysqli_error($con)."<br><br>
<a href=insert_product_details.php><button>Enter New Product Details</button></a>";

mysqli_close($con);
}
}}
?>

</center>
</body>
</html>