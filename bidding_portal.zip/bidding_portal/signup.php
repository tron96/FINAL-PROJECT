 <html>
<head>
<style>
body {
    background-color:#E6E6E6;
}


</style>

</head>
<body>
<center>
<br>
<br><br><br><br>
<?php

require 'config.php';

if(isset($_POST['signup']))
{


$username = $_POST['user_name'];
$firstname = $_POST['first_name'];
$lastname= $_POST['last_name'];
$password = $_POST['password'];
$email = $_POST['email'];
$phone = $_POST['mobile'];


if($username=="" || $firstname=="" || $lastname=="" || $password=="" || $email=="" || $phone=="")
{
	header('location:index.php?message=Please fill completely.');
}
else{
$sql = "INSERT INTO user_details(`username`,`firstname`,`lastname`,`password`,`email_id`,`phone_number`) VALUES('$username','$firstname','$lastname','$password','$email','$phone')";


if (mysqli_query($con,$sql)) {
echo "SignUp completed successfully<br><br>
<a href=index.php><button>Login</button></a>";
} else {
echo "Error: " . mysqli_error($con)."<br><br>
<a href=index.php><button>Go to Registration Form</button></a>";

mysqli_close($con);
}
}}
?>

</center>
</body>
</html>
