<?php 

require 'config.php';

session_start(); // Starting Session
$error=''; // Variable To Store Error Message
if (isset($_POST['login'])) {
if (empty($_POST['username']) || empty($_POST['password'])) {

header("location: index.php?message=Please fill completely");
}
else
{
// Define $username and $password
$username=$_POST['username'];
$password=$_POST['password'];

// To protect MySQL injection for Security purpose
$username = stripslashes($username);
$password = stripslashes($password);

$username = mysqli_real_escape_string($con,$username);
$password = mysqli_real_escape_string($con,$password);
$sql="select * from user_details where password='$password' AND username='$username'";
// SQL query to fetch information of registerd users and finds user match.
$query = mysqli_query($con,$sql);
$rows = mysqli_num_rows($query);
echo $rows;
if ($rows == 1) {
$_SESSION['username']=$username; // Initializing Session
header("location: home.php"); // Redirecting To Other Page
} else {

header("location: index.php?message=Username or Password is incorrect");

}
mysqli_close($con); // Closing Connection
}
}
?>
